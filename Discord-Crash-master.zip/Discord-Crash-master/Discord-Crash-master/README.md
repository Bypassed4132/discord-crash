# Discord-Crash
Crash all Discord clients (desktop, mobile, browser, third party clients,) when user clicks your profile
<p>
<i><b>Discord patched this, the repo will be updated if another solution is found<b></i>
</p>
<h2>Submitting the PUT request</h2>
<p>
  ∙ Navigate to Discord in the browser to find your authorization token <a href="https://discordhelp.net/discord-token">(How To Find Token)</a>
  <br>
  ∙  Change the token in the request to your own, and add some random integers after <i>/contacts/</i><b>HERE</b> 
  <br>
∙ Using your program of choice, submit the PUT request in <b>DiscordCrash.txt</b>
</p>
<br>
<br>
<center>
  <h2>Deleting from your profile</h2>
 
 <p>
  ∙ Navigate to Discord in the browser to find your authorization token
  <br>
  ∙  Change the token in the request to your own, use the same integers after <i>/contacts/</i><b>HERE</b> (important)
  <br>
∙ Using your program of choice, submit the DELETE request in <b>DiscordFix.txt</b>
</p>
<br>
<center><h2>&nbsp;NodeJS</i> </h2></center>
 <p>
  ∙ Navigate to Discord in the browser to find your authorization token
  <br>
  ∙  Change the token in token.txt to your own
  <br>
  ∙ Execute <b>crasher.bat</b>
</p>
<br>
<center>&nbsp; <b>This method does not work on certain Android devices</b></center>
<br>
<h2>PoC</h2>
<img src="https://media.giphy.com/media/J6JNu0bEx04MbZ63fB/giphy.gif">
<br>
<br>
<i>I will be adding some more methods in the future, check back for an update</i>
